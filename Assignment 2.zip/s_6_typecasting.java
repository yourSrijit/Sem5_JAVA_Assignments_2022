package com.Assignment;

import java.util.Scanner;

public class s_6_typecasting {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        long l=sc.nextLong();
        int l1=(int)l;
        System.out.println("Long to int of the num is "+l1);

    }
}
