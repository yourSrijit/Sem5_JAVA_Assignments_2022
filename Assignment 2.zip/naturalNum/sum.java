package com.Assignment.naturalNum;

public class sum {
    public void sum1(int x){
        int n=x;
        int sum=0;
        for(int i=0;i<n;i++){
            sum =sum+i;
        }
        System.out.println("So the sum of natural num is "+sum);
    }
}
